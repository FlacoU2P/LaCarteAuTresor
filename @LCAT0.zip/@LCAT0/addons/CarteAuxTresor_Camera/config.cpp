class CfgPatches
{
	class CarteAuxTresor_Camera
	{
		units[] = {};
		weapons[] = {};
		requiredVersion = 1;
		requiredAddons[] = {"A3_Weapons_F","A3_Weapons_F_Launchers_RPG32"};
	};
};

class Mode_SemiAuto;

class CfgWeapons
{
	class Launcher;
	class Launcher_Base_F: Launcher
	{
		class WeaponSlotsInfo;
	};
	class CarteAuxTresor_Camera_01_F: Launcher_Base_F
	{
		author = "KeviinSkyline";
		_generalMacro = "CarteAuxTresor_Camera_01_F";
		scope = 2;
		displayName = "Camera";
		model = "CarteAuxTresor_Camera\CarteAuxTresor_Cam.p3d";
		picture = "\CarteAuxTresor_camera\UI\UI_Cam.paa";
		UiPicture = "\A3\Weapons_F\Data\UI\icon_at_CA.paa";
		handAnim[] = {"OFP2_ManSkeleton","\A3\Weapons_F_Exp\Launchers\RPG7\Data\Anim\RPG7V.rtm"};
		hiddenSelections[] = {};
		hiddenSelectionsTextures[] = {};
		reloadAction = "ReloadRPG";
		recoil = "recoil_rpg";
		maxZeroing = 600;
		modelOptics = "CarteAuxTresor_camera\CarteAuxTresor_Cam_ViewOptic.p3d";
		weaponInfoType = "RscWeaponEmpty";
		opticsZoomMin = 0.01;
		opticsZoomMax = 1;
		opticsZoomInit = 1;
		cameraDir = "look";
		class GunParticles
		{
			class effect1
			{
				positionName = "konec hlavne";
				directionName = "usti hlavne";
				effectName = "RocketBackEffectsRPGNT";
			};
		};
		class OpticsModes
		{
			class optic
			{
				opticsID = 1;
				useModelOptics = 1;
				opticsZoomMin = 0.01;
				opticsZoomMax = 1;
				opticsZoomInit = 1;
				distanceZoomMin = 100;
				distanceZoomMax = 100;
				memoryPointCamera = "eye";
				opticsFlare = 1;
				opticsDisablePeripherialVision = 1;
				cameraDir = "look";
				visionMode[] = 
				{
					"Normal", //Vision normal
					"NVG"	 //Vision Nocturne
				};
				opticsPPEffects[] = {"OpticsCHAbera1","OpticsBlur1"};
			};
		};
		magazines[] = {"RPG32_F"};
		modes[] = {"Single"};
		class Single: Mode_SemiAuto
		{
			sounds[] = {"StandardSound"};
			class BaseSoundModeType{};
			class StandardSound: BaseSoundModeType
			{
				begin1[] = {"A3\Sounds_F\arsenal\weapons\Launchers\RPG32\rpg32",1.9952624,1,1500};
				soundBegin[] = {"begin1",1};
			};
			recoil = "recoil_single_law";
			aiRateOfFire = 7.0;
			aiRateOfFireDistance = 600;
			minRange = 10;
			minRangeProbab = 0.3;
			midRange = 400;
			midRangeProbab = 0.8;
			maxRange = 600;
			maxRangeProbab = 0.1;
		};
		drySound[] = {"A3\Sounds_F\arsenal\weapons\Launchers\RPG32\Dry_RPG32",0.4466836,1,20};
		reloadMagazineSound[] = {"A3\Sounds_F\arsenal\weapons\Launchers\RPG32\reload_RPG32",1.0,1,10};
		soundFly[] = {"A3\Sounds_F\arsenal\weapons\Launchers\RPG32\Fly_RPG32",0.31622776,1.5,900};
		canLock = 0;
		weaponLockDelay = 3.0;
		lockAcquire = 0;
		inertia = 0.9;
		dexterity = 1.1;
		class WeaponSlotsInfo: WeaponSlotsInfo
		{
			mass = 45;
		};
		descriptionShort = "";
		class Library
		{
			libTextDesc = "";
		};
	};
};